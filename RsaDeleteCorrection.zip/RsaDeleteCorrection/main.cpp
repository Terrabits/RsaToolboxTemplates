

// RsaDeleteCorrection
#include "Settings.h"

// Qt
#include <QString>
#include <QMessageBox>
#include <QApplication>

// Rsa
#include "Definitions.h"
#include "General.h"
#include "Vna.h"
#include "Key.h"
using namespace RsaToolbox;


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    
    // Connect to VNA
    Vna vna(CONNECTION_TYPE,
            INSTRUMENT_ADDRESS,
            TIMEOUT_MS,
            LOG_PATH,
            LOG_FILENAME,
            APP_NAME,
            APP_VERSION);
    
    // Check connection and instrument make/model
    if (vna.isConnected() == false) {
        QString error_message(
                    QString("Instrument could not be found via ")
                    + ToString(CONNECTION_TYPE)
                    + " at address "
                    + QString(INSTRUMENT_ADDRESS));
        QMessageBox::critical(NULL, "RSA Delete Correction", error_message);
        vna.Print(error_message + "\n");
        return(0);
    }
    else if (vna.GetModel() == UNKNOWN_MODEL) {
        QString error_message(QString("VNA not recognized.\n")
                              + "Please use RSA Delete Correction with a Rohde & Schwarz instrument");
        QMessageBox::critical(NULL, "RSA Delete Correction", error_message);
        vna.Print(error_message + "\n");
        return(0);
    }
    
    // Get key instance
    Key key(APP_FOLDER);
    
    
    QString temp_set = "temp_set";
    QString no_cal_group = "no_corrections.cal";
    vna.CreateSet(temp_set);
    vna.Channel().SaveCalGroup(no_cal_group);
    vna.CloseSet(temp_set);

    QVector<uint> channels;
    channels = vna.GetChannels();
    for (int i = 0; i < channels.size(); i++) {
        uint channel_index = channels[i];
        vna.Channel(channel_index).SetCalGroup(no_cal_group);
        vna.Channel(channel_index).DisableCalGroup();
    }

    vna.DeleteCalGroup(no_cal_group);

    
    
    return(0);
}
